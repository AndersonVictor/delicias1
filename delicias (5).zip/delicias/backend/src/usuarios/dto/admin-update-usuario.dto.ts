export class AdminUpdateUsuarioDto {
  nombre?: string;
  apellido?: string;
  email?: string;
  telefono?: string | null;
  direccion?: string | null;
}