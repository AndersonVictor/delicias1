module.exports = [
"[project]/frontend/node_modules/next/navigation.js [app-ssr] (ecmascript)", ((__turbopack_context__, module, exports) => {

module.exports = __turbopack_context__.r("[project]/frontend/node_modules/next/dist/client/components/navigation.js [app-ssr] (ecmascript)");
}),
"[project]/frontend/node_modules/next/image.js [app-ssr] (ecmascript)", ((__turbopack_context__, module, exports) => {

module.exports = __turbopack_context__.r("[project]/frontend/node_modules/next/dist/shared/lib/image-external.js [app-ssr] (ecmascript)");
}),
];

//# sourceMappingURL=9e883_next_08d454b3._.js.map